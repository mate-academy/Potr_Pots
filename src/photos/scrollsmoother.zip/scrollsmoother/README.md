# ScrollSmoother

A Pen created on CodePen.io. Original URL: [https://codepen.io/GreenSock/pen/NWXgqyK](https://codepen.io/GreenSock/pen/NWXgqyK).

