import { useDynamicAdapt } from './src/dynamicAdapt.js'

useDynamicAdapt()
